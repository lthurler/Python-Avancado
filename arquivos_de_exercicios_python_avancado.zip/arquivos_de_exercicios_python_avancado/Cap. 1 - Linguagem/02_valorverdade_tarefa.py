# TODO: Mostre o valor booleano de uma lista vazia


# TODO: Mostre o valor booleano de um dicionario vazio
