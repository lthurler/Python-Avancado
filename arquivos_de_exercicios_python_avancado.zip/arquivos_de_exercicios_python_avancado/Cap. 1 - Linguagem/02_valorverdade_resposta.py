# Mostre o valor booleano de uma lista vazia
x = []
print(bool(x))

# Mostre o valor booleano de um dicionario vazio
y = {}
print(bool(y))