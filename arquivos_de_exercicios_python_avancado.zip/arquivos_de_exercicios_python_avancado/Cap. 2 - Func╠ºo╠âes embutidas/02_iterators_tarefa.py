# Usando funções iteradoras como enumerate, zip, iter, next


def main():
    # Defina a lista de dias da semana em Português e English
    dias = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sab"]
    dias_en = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]

    # TODO: Use a função iter para criar um iterador sobre uma lista

    # TODO: Use uma função para iterar sobre um arquivo

    # TODO: Use a iteração tradicional (range) sobre a lista dias

    # TODO: Usar a função enumerate reduz a quantidade de código e te
    # dá um contador

    # TODO: Use a função zip para combinar as listas

    # TODO: Combine zip com enumerate para formatar o resultado


if __name__ == "__main__":
    main()
