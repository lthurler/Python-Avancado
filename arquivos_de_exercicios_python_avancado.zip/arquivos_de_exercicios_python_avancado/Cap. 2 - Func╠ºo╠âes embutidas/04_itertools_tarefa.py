# Iteradores do módulo itertools
import itertools


def condicao():
    pass


def main():
    # TODO: Iterador cycle pode ser usado como o iter para iterar sobre
    # uma lista
    pessoas = ["Jessica", "Leticia", "Gustavo"]

    # TODO: Use count para criar um contador

    # TODO: A função accumulate cria um iterdor que acumula valores
    valores = [10, 20, 30, 40, 50, 40, 30]

    # TODO: Use a função chain para conectar listas

    # TODO: As funções dropwhile e takewhile vai retornar valores até
    # que uma condição seja atingida


if __name__ == "__main__":
    main()
