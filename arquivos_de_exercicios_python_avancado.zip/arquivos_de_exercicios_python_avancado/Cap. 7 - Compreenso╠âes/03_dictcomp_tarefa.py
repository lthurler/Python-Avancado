# Usando dict comprehensions


def main():
    # Definindo uma lista de temperaturas
    ctemps = [0, 12, 34, 100]

    # TODO: Use a comprehension to build a dictionary
    # Dica: Fórmula pra converter para Fahrenheit -> (t * 9/5) + 32


if __name__ == "__main__":
    main()
