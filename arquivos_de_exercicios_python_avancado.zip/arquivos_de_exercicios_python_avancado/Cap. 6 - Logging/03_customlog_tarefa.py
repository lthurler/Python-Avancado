# Personalizando o retorno do logging
import logging


# TODO: Crie uma outra função para rodar o log


def main():
    # TODO: Defina o nível de log para debug e um arquivo para salvar
    # o retorno. Use também uma formatação personalizada
    logging.info("Esta é uma mensagem de informação", extra=dados)
    logging.warning("Esta é uma mensagem de aviso", extra=dados)


if __name__ == "__main__":
    main()
