# Uso de argumentos variáveis


# TODO: Defina uma função que recebe argumentos variáveis
def adicao():
    pass


def main():
    # TODO: Passe argumentos diferentes para o método adicao()

    # TODO: Passe uma lista para o método adicao()


if __name__ == "__main__":
    main()
