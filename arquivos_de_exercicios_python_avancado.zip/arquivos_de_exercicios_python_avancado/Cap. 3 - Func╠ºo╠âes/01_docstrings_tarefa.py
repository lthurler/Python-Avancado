# Usando docstrings para documentar métodos


def minha_funcao():
    pass


def main():
    print(minha_funcao.__doc__)


if __name__ == "__main__":
    main()
