# Usando a classe Counter
from collections import Counter


def main():
    # Uma lista de estudantes na turma A
    turma_a = ["Bárbara", "João", "Carlos", "Dário", "Priscila", "Ana"
               "Kevin", "João", "Marina", "Bianca", "Gustavo",
               "Fernanda"]

    # Uma lista de estudantes na turma B
    turma_b = ["Hiro", "Bruno", "Claudia", "Débora", "Fernanda",
               "Gabriela", "Leticia", "João", "Jairo", "Samuel",
               "Taciana", "Gabriel"]

    # TODO: Crie um Counter para as turmas A e B

    # TODO: Quantos estudantes na turma A se chamam João?

    # TODO: Quantos estudantes estão na turma A?

    # TODO: Combine as duas turmas

    # TODO: Quais os 3 nomes mais comuns nas duas turmas?

    # TODO: Separe as duas turmas e mostre o nome mais comum da turma a

    # TODO: Qual a intersecção de nomes entre as duas turmas?


if __name__ == "__main__":
    main()
