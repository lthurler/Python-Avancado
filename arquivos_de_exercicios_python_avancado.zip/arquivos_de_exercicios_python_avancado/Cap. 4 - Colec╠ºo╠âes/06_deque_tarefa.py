# Deques são filas duplamente terminadas
import collections
import string


def main():
    # TODO: Inicialize um deque com letras minúsculas

    # TODO: Deques suportam o método len(), mostre o tamanho da deque

    # TODO: Itere sobre a deque criada

    # TODO: Manipule os itens em qualquer um dos terminais


    # TODO: Rotacione a deque


if __name__ == "__main__":
    main()
