# Uso de objetos namedtuple
import collections


def main():
    # TODO: Crie uma namedtuple para armazenar coordenadas

    # TODO: Use _replace() para criar uma instância nova


if __name__ == "__main__":
    main()
