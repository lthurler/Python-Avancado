# define enumerations using the Enum base class

# TODO: Defina a classe Fruta que herda de Enum


def main():
    pass
    # TODO: Objetos enum possuem valores e tipos de fácil leitura

    # TODO: Objetos enum possuem propriedades "name" (nome) e
    # "value" (valor)

    # TODO: Mostre o valor gerado automaticamente para PERA)

    # TODO: É possível usar objetos enum como chaves


if __name__ == "__main__":
    main()
