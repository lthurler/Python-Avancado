# Personalizando a representação string de uma classe


class MinhasCores():
    def __init__(self):
        self.red = 50
        self.green = 75
        self.blue = 100

    # TODO: Use getattr para retornar um valor de forma dinâmica

    # TODO: Use setattr para retornar um valor de forma dinâmica

    # TODO: Use dir para listar os atributos disponíveis


def main():
    # Criando uma instância de MinhasCores
    cores = MinhasCores()

    # TODO: Mostre o valor de um atributo

    # TODO: Defina o valor de um atributo

    # TODO: Acesse um atributo específico

    # TODO: Liste os atributos disponíveis


if __name__ == "__main__":
    main()
